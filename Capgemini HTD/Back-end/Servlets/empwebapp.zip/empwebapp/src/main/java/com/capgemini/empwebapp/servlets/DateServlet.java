package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlet extends HttpServlet {
	
	public DateServlet() {
		System.out.println("It's Instantiation Phase!");
	}

	@Override
	public void init() throws ServletException {
		System.out.println("It's Initialization Phase!");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("It's Service Phase!");

		Date date = new Date();

//		resp.setHeader("refresh", "1"); //auto-reload page after 1 second
		resp.setContentType("text/html");

		ServletContext context = getServletContext();
		String companyNameVal = context.getInitParameter("companyName");

		PrintWriter out = resp.getWriter();
		out.println("<html>");
//		out.println("<head>");
//		out.println("<meta http-equiv='refresh' content='1'>"); //auto-reload page after 1 second
//		out.println("</head>");
		out.println("<body>");
		out.println("<h1>Current System Date and Time<h1>");
		out.println(date + "</h1>");
		out.print("<h2>Context Param Value is: " + companyNameVal + "<h2>");
		out.println("</body>");
		out.println("</html>");
	}// End of doGet()

	@Override
	public void destroy() {
		super.destroy();
		System.out.println("It's Destroy Phase!");
	}

} // End of class
