package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;
import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoJpaImpl;

@WebServlet("/updateEmployee")
public class UpdateEmployeeServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(false);
		if (session != null) {
			// valid session
			// get the form data
			
			int emp_id = Integer.parseInt(req.getParameter("emp_id"));
			String emp_name = req.getParameter("emp_name");
			String ageVal = req.getParameter("age");
			String salaryVal = req.getParameter("salary");
			String designation = req.getParameter("designation");
			String genderVal = req.getParameter("gender");
			String mobileVal = req.getParameter("mobile");
			String password = req.getParameter("password");
			
			EmployeeInfoBean employeeInfoBean = new EmployeeInfoBean();
			employeeInfoBean.setEmp_id(emp_id);
			if(emp_name != null && !emp_name.isEmpty()) {
				employeeInfoBean.setEmp_name(emp_name);
			}
			
			if(ageVal != null && !ageVal.isEmpty()) {
				employeeInfoBean.setAge(Integer.parseInt(ageVal));
			}
			
			if(salaryVal != null && !salaryVal.isEmpty()) {
				employeeInfoBean.setSalary(Double.parseDouble(salaryVal));
			}
			
			if(genderVal != null && !genderVal.isEmpty()) {
				employeeInfoBean.setGender(genderVal.charAt(0));
			}
			
			if(designation != null && !designation.isEmpty()) {
				employeeInfoBean.setDesignation(designation);
			}
			
			if(mobileVal != null && !mobileVal.isEmpty()) {
				employeeInfoBean.setMobile(Long.parseLong(mobileVal));
			}
			
			if(password != null && !password.isEmpty()) {
				employeeInfoBean.setDesignation(password);
			}
			
			EmployeeDao dao = new EmployeeDaoJpaImpl();
			boolean isUpdated = dao.updateEmployee(employeeInfoBean);

			PrintWriter out = resp.getWriter();
			out.print("<html>");
			out.print("<body>");
			if (isUpdated) {
				out.println("<h2>Employee record updated successfully!</h2>");
			} else {
				out.println("<h2 style = 'color:red'>Unable to update Employee record!!");
			}
			out.print("</body>");
			out.print("</html>");
			
			RequestDispatcher dispatcher = req.getRequestDispatcher("./updateEmployeeForm.html");
			dispatcher.include(req, resp);
			
		} else {
			// Invalid Session
			PrintWriter out = resp.getWriter();
			out.print("<html>");
			out.print("<body>");
			out.println("<h2 style='color: red'>Please Login First!</h2>");
			out.print("</body>");
			out.print("</html>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("./loginForm.html");
			dispatcher.include(req, resp);
		}
	}
}
