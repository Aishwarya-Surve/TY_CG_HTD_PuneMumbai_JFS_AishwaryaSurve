package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;
import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoJpaImpl;

@WebServlet("/searchEmployee")
public class SearchEmployeeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Get the form data
		String empIdVal = req.getParameter("emp_id");
		int emp_id = Integer.parseInt(empIdVal);

		EmployeeDao dao = new EmployeeDaoJpaImpl();
		EmployeeInfoBean employeeInfoBean = dao.getEmployee(emp_id);

		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("<html>");
		out.print("<body>");
		if (employeeInfoBean != null) {
			// Display emp record
			out.println("<h2>Employee ID " + emp_id + "Found-</h2>");
			out.println("Employee Name= " + employeeInfoBean.getEmp_name());
			out.println("<br> Age= " + employeeInfoBean.getAge());
			out.println("<br> Salary= " + employeeInfoBean.getSalary());
			out.println("<br> Designation= " + employeeInfoBean.getDesignation());
			out.println("<br> Gender= " + employeeInfoBean.getGender());
			out.println("<br> Mobile= " + employeeInfoBean.getMobile());
			out.println("<br> Password= " + employeeInfoBean.getPassword());
		} else {
			// Display error message
			out.println("<h3 style='color: red>Employee ID " + emp_id + "Not Found!");
		}
		out.print("</body>");
		out.print("</html>");
	}// End of doGet()

}// End of class
