package com.capgemini.empwebapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;

public class EmployeeDaoJpaImpl implements EmployeeDao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeePersistenceUnit");

	@Override
	public EmployeeInfoBean getEmployee(int emp_id) {

		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean employeeInfoBean = manager.find(EmployeeInfoBean.class, emp_id);
		manager.close();
		return employeeInfoBean;
	}// End of getEmployee()

	@Override
	public EmployeeInfoBean authenticate(int emp_id, String password) {
		EntityManager manager = emf.createEntityManager();
//		EmployeeInfoBean employeeInfoBean = manager.find(EmployeeInfoBean.class, emp_id);
//		manager.close();
//		if (password.equals(employeeInfoBean.getPassword())) {
//			return true;
//		} else {
//			return false;
//		}

		String jpql = "from EmployeeInfoBean where emp_id = :emp_id and password = :password";
		Query query = manager.createQuery(jpql);
		query.setParameter("emp_id", emp_id);
		query.setParameter("password", password);

		EmployeeInfoBean employeeInfoBean = null;
		try {
			employeeInfoBean = (EmployeeInfoBean) query.getSingleResult();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return employeeInfoBean;
	}// End of authenticate()

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdded = false;
		try {
			tx.begin();
			manager.persist(employeeInfoBean);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isAdded;
	}// End of addEmloyee()

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean employeeInfoBean1 = manager.find(EmployeeInfoBean.class, employeeInfoBean.getEmp_id());
		boolean isUpdated = false;
		if (employeeInfoBean1 != null) {

			String name = employeeInfoBean1.getEmp_name();
			if (name != null) {
				employeeInfoBean1.setEmp_name(name);
			}

			int age = employeeInfoBean1.getAge();
			if (age > 18) {
				employeeInfoBean1.setAge(age);
			}

			double salary = employeeInfoBean1.getSalary();
			if (salary > 0) {
				employeeInfoBean1.setSalary(salary);
			}

			long mobile = employeeInfoBean1.getMobile();
			if (mobile > 0) {
				employeeInfoBean1.setMobile(mobile);
			}

			String designation = employeeInfoBean1.getDesignation();
			if (name != null) {
				employeeInfoBean1.setDesignation(designation);
			}

			char gender = employeeInfoBean1.getGender();
			if (gender == 'M' || gender == 'F' || gender == 'm' || gender == 'f') {
				employeeInfoBean1.setGender(gender);
			}

			String password = employeeInfoBean1.getPassword();
			if (password != null) {
				employeeInfoBean1.setPassword(password);
			}
			try {
				EntityTransaction tx = manager.getTransaction();
				tx.begin();
				manager.persist(employeeInfoBean1);
				tx.commit();
				isUpdated = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			manager.close();
		}
		return isUpdated;
	}// End of updateEmployee()
}// End of class
