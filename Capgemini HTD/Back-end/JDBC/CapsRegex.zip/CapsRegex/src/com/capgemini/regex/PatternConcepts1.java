package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts1 {

	public static void main(String[] args) {

		Pattern pat = Pattern.compile("\\d"); // Single digit
		Matcher mat = pat.matcher("4");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\d+"); // Multiple digits
		mat = pat.matcher("45678");
		System.out.println("For pattern \\d+: " + mat.matches());

		pat = Pattern.compile("\\d{10}"); // Only 10 digits
		mat = pat.matcher("1234567890");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\d{1,10}"); // Only 1 to 10 digits
		mat = pat.matcher("1234567890");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\d{0}"); // 0 digits
		mat = pat.matcher("");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\d{1,9}"); //
		mat = pat.matcher("123456789");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\d{1,9}"); // 
		mat = pat.matcher("12345678");
		System.out.println("For pattern \\d: " + mat.matches());

		pat = Pattern.compile("\\D"); // Can Match anything but not a digit (Single)
		mat = pat.matcher("@");
		System.out.println("For pattern \\D: " + mat.matches());
		
		pat = Pattern.compile("\\D+"); // Can Match anything but not a digit (Multiple)
		mat = pat.matcher("@A>Z");
		System.out.println("For pattern \\D: " + mat.matches());
		
		pat = Pattern.compile("\\s"); // single space
		mat = pat.matcher(" ");
		System.out.println("For pattern \\s: " + mat.matches());
		
		pat = Pattern.compile("\\s+"); // multiple spaces
		mat = pat.matcher("    ");
		System.out.println("For pattern \\s+: " + mat.matches());
		
		pat = Pattern.compile("\\S"); // No Space
		mat = pat.matcher("@");
		System.out.println("For pattern \\S: " + mat.matches());

	}

}
