package com.dev.dummy.bean;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@SuppressWarnings("serial")
@Data
public class UserBeanLombok implements Serializable {

	public UserBeanLombok() {
		super();
	}

	private int userid;
	private String username;
	private String email;
	@ToString.Exclude
	private String password;
}
