package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCInsertion {

	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {

			// Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("************************");

			// Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			
			System.out.println("Enter the username and password: ");
			String user = sc.nextLine();
			String password = sc.nextLine();
			
			conn = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("Connection Estsblished....");
			System.out.println("*************************");

			// Issue SQL Query via Connection
			String query = "INSERT INTO users_info values(?,?,?,?)";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter User ID: ");
			pstmt.setInt(1, Integer.parseInt(sc.nextLine()));
			System.out.println("Enter User Name: ");
			pstmt.setString(2, sc.nextLine());
			System.out.println("Enter Email: ");
			pstmt.setString(3, sc.nextLine());
			System.out.println("Enter Password: ");
			pstmt.setString(4, sc.nextLine());
			
			int count = pstmt.executeUpdate();
			
			//Process the result
			if(count > 0) {
				System.out.println("Data Inserted....");
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		sc.close();
	}

}
