package com.capgemini.jdbc;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCRetrivalAll2 {
	
	public static void main(String[] args) {

		Connection conn = null;
		FileReader reader = null;
		Properties prop = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {

			// Load the Driver
			java.sql.Driver driver = new com.mysql.jdbc.Driver();
			DriverManager.registerDriver(driver);
			System.out.println("Driver Loaded....");
			System.out.println("**************************");

			// Get Connection
			String dburl = prop.getProperty("dburl");
			conn = DriverManager.getConnection(dburl, prop);
			System.out.println("Connection Established....");
			System.out.println("***********************");

			// Issue SQL Query via Connection
			String query = "SELECT * FROM users_info";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			// Process the Results returned by SQL Query
			while (rs.next()) {

				System.out.println("User ID: " + rs.getInt("user_id"));
				System.out.println("User Name: " + rs.getString("username"));
				System.out.println("Email: " + rs.getString("email"));
				System.out.println("Password: " + rs.getString("password"));
				System.out.println("***************************");

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}


}
