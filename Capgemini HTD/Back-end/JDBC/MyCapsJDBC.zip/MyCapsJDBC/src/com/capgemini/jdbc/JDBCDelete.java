package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCDelete {

	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {

			// Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("************************");

			// Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			
			System.out.println("Enter the username and password: ");
			String user = sc.nextLine();
			String password = sc.nextLine();
			
			conn = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("Connection Established....");
			System.out.println("*************************");

			// Issue SQL Query via Connection
			String query = "DELETE FROM users_info WHERE user_id = ?";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter User ID to delete the record: ");
			pstmt.setInt(1, Integer.parseInt(sc.nextLine()));
			
			int count = pstmt.executeUpdate();
			
			//Process the result
			if(count > 0) {
				System.out.println("Data Deleted....");
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		sc.close();
	}

}
