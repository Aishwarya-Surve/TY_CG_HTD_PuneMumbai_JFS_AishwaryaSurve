package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCUpdate {

	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {

			// Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("************************");

			// Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			
			System.out.println("Enter the username and password: ");
			String user = sc.nextLine();
			String password = sc.nextLine();
			
			conn = DriverManager.getConnection(dbUrl , user, password);
			System.out.println("Connection Established....");
			System.out.println("*************************");

			// Issue SQL Query via Connection
			String query = "UPDATE users_info set email = ? WHERE user_id = ? and password = ?";
			
			pstmt = conn.prepareStatement(query);
		
			System.out.println("Enter new Email: ");
			pstmt.setString(1, sc.nextLine());
			System.out.println("Enter User ID: ");
			pstmt.setInt(2, Integer.parseInt(sc.nextLine()));
			System.out.println("Enter Password: ");
			pstmt.setString(3, sc.nextLine());
			
			int count = pstmt.executeUpdate();
			
			//Process the result
			if(count > 0) {
				System.out.println("Data Updated....");
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		sc.close();
	}

}
