package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JDBCInsertValidate {

	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {

			// Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded....");
			System.out.println("************************");

			// Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";

			System.out.println("Enter the username and password: ");
			String user = sc.nextLine();
			String password = sc.nextLine();

			conn = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("Connection Estsblished....");
			System.out.println("*************************");

			// Issue SQL Query via Connection
			String query = "INSERT INTO users_info values(?,?,?,?)";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter User ID: ");
			
			String pass3 = sc.nextLine();
			Pattern pattern = Pattern.compile("\\d{7}"); // ID of 7 digits
			Matcher matcher = pattern.matcher(pass3);
			boolean b4 = matcher.matches();
			if (b4 == true) {

				pstmt.setString(1, pass3);

			} else {

				System.out.println("Please enter valid ID!");

			}
			
			System.out.println("Enter User Name: ");

			String pass2 = sc.nextLine();
			pattern = Pattern.compile("\\w+\\s\\w+"); // name with surname
			matcher = pattern.matcher(pass2);
			boolean b3 = matcher.matches();
			if (b3 == true) {

				pstmt.setString(2, pass2);

			} else {

				System.out.println("Please enter name with surname!");

			}

			System.out.println("Enter Email: ");

			String pass = sc.nextLine();
			pattern = Pattern.compile("\\w+\\@\\w+\\.\\w+");
			matcher = pattern.matcher(pass);
			boolean b = matcher.matches();
			if (b == true) {

				pstmt.setString(3, pass);

			} else {

				System.out.println("Please enter valid Email Id!");

			}

			System.out.println("Enter Password: ");

			String pass1 = sc.nextLine();
			pattern = Pattern.compile("\\w+\\W+\\w+"); // Alphanumeric password
			matcher = pattern.matcher(pass1);
			boolean b1 = matcher.matches();
			if (b1 == true) {

				pstmt.setString(4, pass1);

			} else {

				System.out.println("Please enter strong password!");

			}

			int count = pstmt.executeUpdate();

			// Process the result
			if (count > 0) {
				System.out.println("Data Inserted....");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		sc.close();
	}

}
