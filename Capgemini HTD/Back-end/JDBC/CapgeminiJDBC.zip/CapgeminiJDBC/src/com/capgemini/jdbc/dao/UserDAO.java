package com.capgemini.jdbc.dao;

import java.util.List;

import com.capgemini.jdbc.beans.UserBean;

public interface UserDAO {
	
	public List<UserBean> getAllInfo();

	public UserBean getInfo(int user_id);
	
	public UserBean getLogin(int user_id, String password);

}
