package com.capgemini.jpawithhibernateassign;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernateassign.dto.BoyBands;


public class Reattaching {

	public static void main(String[] args) {

		EntityManager entityManager = null;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			
			transaction.begin();
			BoyBands data = entityManager.find(BoyBands.class, 104);
			System.out.println(data.getId());
			System.out.println(entityManager.contains(data));
			entityManager.detach(data);
			//entityManager.clear();
			System.out.println(entityManager.contains(data));
			BoyBands data1 = entityManager.merge(data);
			data1.setName("TxT");
			transaction.commit();
			
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();

	}

}
