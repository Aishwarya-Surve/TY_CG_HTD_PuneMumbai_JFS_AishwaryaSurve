package com.capgemini.jpawithhibernateassign;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernateassign.dto.BoyBands;

public class Reference {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//Movie data = entityManager.find(Movie.class, 1);
		BoyBands getData = entityManager.getReference(BoyBands.class, 101);
		System.out.println("Id: " + getData.getId());
		System.out.println("Name: " + getData.getName());
		System.out.println("Ratings: " + getData.getRatings());

	}

}
