package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Retrival {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		String jpql = "from Movie";
		Query query = entityManager.createQuery(jpql);
		List<Movie> list = query.getResultList();
		
		for(Movie m : list) {
			System.out.println("Id: "+m.getId());
			System.out.println("Name: "+m.getName());
			System.out.println("Ratings: "+m.getRatings());
		}
		entityManager.close();
	}

}
