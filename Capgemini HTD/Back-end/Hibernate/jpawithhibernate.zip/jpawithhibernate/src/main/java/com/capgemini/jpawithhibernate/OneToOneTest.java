package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetoone.Person;
import com.capgemini.jpawithhibernate.onetoone.VoterCard;

public class OneToOneTest {

	public static void main(String[] args) {

		Person p = new Person();
		p.setId(1);
		p.setName("Aishwarya");
		VoterCard vc = new VoterCard();
		vc.setVoter_id(1234);
		vc.setAddress("Qspiders");
		p.setVoterCard(vc);

		EntityManager entityManager = null;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			VoterCard cardDetail = entityManager.find(VoterCard.class, 1234);
			cardDetail.getVoter_id();
			cardDetail.getAddress();
			cardDetail.getPerson().getId();
			cardDetail.getPerson().getName();
			System.out.println("Saved");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();

	}

}
