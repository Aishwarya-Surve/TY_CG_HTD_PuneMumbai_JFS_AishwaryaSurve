package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetomany.Pencil;
import com.capgemini.jpawithhibernate.onetomany.PencilBox;

public class ManyToOneTest {

	public static void main(String[] args) {

		PencilBox pencilbox = new PencilBox();
		pencilbox.setBoxid(101);
		pencilbox.setName("Camlin");

		Pencil pencil = new Pencil();
		pencil.setId(1);
		pencil.setColor("Black");
		pencil.setPencilbox(pencilbox);

		Pencil pencil1 = new Pencil();
		pencil1.setId(2);
		pencil1.setColor("Grey");
		pencil1.setPencilbox(pencilbox);

		EntityManager entityManager = null;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();

			entityManager.persist(pencil);
			entityManager.persist(pencil1);

			System.out.println("Saved");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();

	}

}
