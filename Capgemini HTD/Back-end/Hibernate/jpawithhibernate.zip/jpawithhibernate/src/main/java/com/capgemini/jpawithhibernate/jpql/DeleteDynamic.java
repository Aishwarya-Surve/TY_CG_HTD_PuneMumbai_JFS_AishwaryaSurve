package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DeleteDynamic {

	public static void main(String[] args) {

		EntityTransaction transaction = null;

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		transaction = entityManager.getTransaction();
		transaction.begin();
		String jpql = "delete from Movie where id =:mid";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("mid", 5);
		int result = query.executeUpdate();
		transaction.commit();
		System.out.println("Result: " + result);
		entityManager.close();
		
	}

}
