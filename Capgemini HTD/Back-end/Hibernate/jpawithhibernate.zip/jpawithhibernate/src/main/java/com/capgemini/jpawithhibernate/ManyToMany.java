package com.capgemini.jpawithhibernate;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.manytomany.Course;
import com.capgemini.jpawithhibernate.manytomany.Student;

public class ManyToMany {

	public static void main(String[] args) {

		Course course = new Course();
		course.setCid(101);
		course.setCname("JAVA");
		Course course1 = new Course();
		course1.setCid(102);
		course1.setCname("Python");
		ArrayList<Course> al = new ArrayList<Course>();
		al.add(course);
		al.add(course1);

		Student student = new Student();
		student.setSid(1);
		student.setSname("Aishwarya");
		student.setCourse(al);

		EntityManager entityManager = null;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();

			// entityManager.persist(student);
			// entityManager.persist(course);

			Course course2 = entityManager.find(Course.class, 101);
			course2.getStudent().get(0).getSid();

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

	}

}
