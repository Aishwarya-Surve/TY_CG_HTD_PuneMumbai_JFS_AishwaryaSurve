package com.capgemini.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
import com.capgemini.springmvc.dao.EmployeeDao;

@Service // or @Component
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Override
	public EmployeeInfoBean getEmployee(int emp_id) {

		return dao.getEmployee(emp_id);
	}

	@Override
	public EmployeeInfoBean authenticate(int emp_id, String password) {

		return dao.authenticate(emp_id, password);
	}

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {

		return dao.addEmployee(employeeInfoBean);
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		return dao.updateEmployee(employeeInfoBean);
	}

	@Override
	public boolean deleteEmployee(int emp_id) {
		return dao.deleteEmployee(emp_id);
	}

	@Override
	public List<EmployeeInfoBean> getAllEmployees() {
		return dao.getAllEmployees();
	}

}
