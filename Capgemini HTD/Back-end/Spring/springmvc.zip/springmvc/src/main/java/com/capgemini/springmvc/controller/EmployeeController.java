package com.capgemini.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
import com.capgemini.springmvc.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/empLoginForm")
	public String displayEmpLoginForm() {

		return "empLoginForm";

	}// End of displayEmpLoginForm()

	@PostMapping("/empLogin")
	public String empLogin(int emp_id, String password, ModelMap modelMap, HttpServletRequest req) {

		EmployeeInfoBean employeeInfoBean = service.authenticate(emp_id, password);

		if (employeeInfoBean != null) {
			// Valid Credentials
			HttpSession session = req.getSession(true);
			session.setAttribute("employeeInfoBean", employeeInfoBean);

			return "empHomePage";
		} else {
			// Invalid Credentials
			modelMap.addAttribute("msg", "Invalid Login Credentials!");
			return "empLoginForm";
		}
	}// End of empLogin()

	@GetMapping("/addEmployeeForm")
	public String displayAddEmpForm(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please Login First!!");
			return "empLoginForm";
		} else {
			return "addEmployeeForm";
		}

	}// End of displayAddEmpForm()

	@PostMapping("/addEmployee")
	public String addEmployee(EmployeeInfoBean employeeInfoBean, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First!!");
			return "empLoginForm";
		} else {
			// Valid Session
			if (service.addEmployee(employeeInfoBean)) {
				modelMap.addAttribute("msg", "Employee added sucessfully!");
			} else {
				modelMap.addAttribute("msg", "Unable to add Employee!");
			}
			return "addEmployeeForm";
		}
	}// End of addEmployee()

	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap) {
		session.invalidate();
		modelMap.addAttribute("msg", "Loggedout Sucessfully!");
		return "empLoginForm";
	}// End of logout()

	@GetMapping("/updateEmployeeForm")
	public String displayUpdateEmpForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			return "updateEmployeeForm";
		}

	}// End of displayUpdateEmpForm()

	@PostMapping("/updateEmployee")
	public String updateEmployee(EmployeeInfoBean employeeInfoBean, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			if (service.updateEmployee(employeeInfoBean)) {
				modelMap.addAttribute("msg", "Employee Details Updated Successfully...");
			} else {
				modelMap.addAttribute("msg", "Unable to update Employee Details!!!");
			}
			return "updateEmployeeForm";
		}
	}// End of updateEmployee()

	@GetMapping("/searchEmployeeForm")
	public String displaySearchEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			return "searchEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()

	@GetMapping("/searchEmployee")
	public String searchEmployee(int emp_id, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			EmployeeInfoBean employeeInfoBean = service.getEmployee(emp_id);
			if (employeeInfoBean != null) {
				modelMap.addAttribute("employeeInfoBean", employeeInfoBean);
			} else {
				modelMap.addAttribute("msg", "Employee ID " + emp_id + " Not Found!!!");
			}

			return "searchEmployeeForm";
		}
	}// End of searchEmployee()

	@GetMapping("/deleteEmployeeForm")
	public String displayDeleteEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			return "deleteEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()

	@GetMapping("/deleteEmployee")
	public String deleteEmployee(int emp_id, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			if (service.deleteEmployee(emp_id)) {
				modelMap.addAttribute("msg", "Employee Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "Employee ID " + emp_id + " Not Found!");
			}

			return "deleteEmployeeForm";
		}
	}// End of deleteEmployee()

	@GetMapping("/seeAllEmployees")
	public String getAllEmployees(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			List<EmployeeInfoBean> employeesList = service.getAllEmployees();
			modelMap.addAttribute("employeesList", employeesList);

			return "displayAllEmployees";
		}
	}// End of getAllEmployees()

	@GetMapping("/home")
	public String displayEmpHomePage(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";

		} else {
			// Valid Session
			return "empHomePage";
		}
	}// End of displayEmpHomePage()

}// End of Controller
