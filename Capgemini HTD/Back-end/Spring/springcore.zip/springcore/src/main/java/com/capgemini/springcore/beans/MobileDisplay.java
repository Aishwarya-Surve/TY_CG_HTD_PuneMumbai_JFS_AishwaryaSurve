package com.capgemini.springcore.beans;

public class MobileDisplay {

	private float displaySize;
	private int resolution;

	public float getDisplaySize() {
		return displaySize;
	}

	public void setDisplaySize(float displaySize) {
		this.displaySize = displaySize;
	}

	public int getResolution() {
		return resolution;
	}

	public void setResolution(int resolution) {
		this.resolution = resolution;
	}

}
