package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;
import com.capgemini.springcore.beans.Mobile;

public class MobileTest {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("mobileConfig.xml");
		Mobile mobile = context.getBean("mobile", Mobile.class);
		System.out.println("Brand Name  : " + mobile.getBrandName());
		System.out.println("Model Name  : " + mobile.getModelName());
		System.out.println("Price       : " + mobile.getPrice());
		System.out.println("Display Size: " + mobile.getMobileDisplay().getDisplaySize());
		System.out.println("Resolution  : " + mobile.getMobileDisplay().getResolution());
	}
}
