package com.capgemini.springcore.annotations.beans;

import com.capgemini.springcore.interfaces.Engine;

public class ISuzu implements Engine {

	@Override
	public int getCC() {

		return 1700;
	}
  
	@Override
	public String getType() {

		return "ISuzu : 4-Stroke Petrol";
	}

}//End of class
