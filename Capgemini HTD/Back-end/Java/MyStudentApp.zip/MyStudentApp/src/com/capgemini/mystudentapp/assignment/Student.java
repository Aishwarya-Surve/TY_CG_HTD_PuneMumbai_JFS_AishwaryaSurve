package com.capgemini.mystudentapp.assignment;

public class Student {
	int id;
	String name;
	double percenatage;

	public Student(int id, String name, double percenatage) {
		this.id = id;
		this.name = name;
		this.percenatage = percenatage;
	}
}
