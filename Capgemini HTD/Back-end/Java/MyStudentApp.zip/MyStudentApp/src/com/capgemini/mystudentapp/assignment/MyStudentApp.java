package com.capgemini.mystudentapp.assignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class MyStudentApp {

	private static ArrayList<Student> al = new ArrayList<Student>();
	private static final Scanner scan = new Scanner(System.in);

	void addStudent() {
		System.out.println("Enter the Name");

		String name = scan.nextLine();

		System.out.println("Enter the ID");
		int id = scan.nextInt();

		System.out.println("Enter the percenatage");
		double percentage = scan.nextDouble();

		Student s = new Student(id, name, percentage);

		al.add(s);
	}

	void display() {
		Iterator<Student> it = al.iterator();
		while (it.hasNext()) {
			while (it.hasNext()) {
				Student s = it.next();
				System.out.println("Name is " + s.name);
				System.out.println("ID is " + s.id);
				System.out.println("Percentage is " + s.percenatage);
				System.out.println("-----------------------------------------");
			}
		}
	}

}