package com.capgemini.mystudentapp.assignment;

import java.util.Scanner;

public class TestStudent {
	public static void main(String[] args) {

		MyStudentApp m = new MyStudentApp();

		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("Enter the option \n 1: To add student \n 2: Display Student" + "\n3: Exit");
			int opt = scan.nextInt();

			switch (opt) {
			case 1:
				m.addStudent();
				break;
			case 2:
				m.display();
				break;
			case 3:
				System.exit(0);
			default:
				System.out.println("Are you mad to enter the wrong option");
			}
		}

	}
}
