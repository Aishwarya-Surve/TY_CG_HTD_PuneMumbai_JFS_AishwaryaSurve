package com.capgemini.maps.examples;

import java.util.LinkedHashMap;
import java.util.Map;

public class Map5 {
	
	public static void main(String[] args) {

		LinkedHashMap<String, Integer> hm = new LinkedHashMap<String, Integer>();
		hm.put("Ondhu", 1);
		hm.put("Idhu", 5);
		hm.put("Hathu", 10);
		hm.put("Eredu", 2);
		
		
	}


}
