package com.capgemini.maps.examples;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class Map4 {
	
	public static void main(String[] args) {

		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		hm.put("Ondhu", 1);
		hm.put("Idhu", 5);
		hm.put("Hathu", 10);
		hm.put("Eredu", 2);
		
		System.out.println("**********Keys**********");
		Set<String> s = hm.keySet();
		for(String r : s) {
			
			System.out.println(r);
		}
		
		System.out.println("**********Values*********");
		Collection<Integer> col =hm.values();
		for(Integer r : col) {
			
			System.out.println(r);
			
		}
	}


}
