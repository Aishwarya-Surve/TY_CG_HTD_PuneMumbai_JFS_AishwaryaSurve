package com.capgemini.maps.examples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class TestStudent {

	public static void main(String[] args) {

		LinkedHashMap lhm = new LinkedHashMap<String, ArrayList<Student>>();
		Student s1 = new Student(1, "Aishwarya", 89.82);
		Student s2 = new Student(2, "Taehyung", 80.82);
		Student s3 = new Student(3, "Zayn", 70.45);
		Student s4 = new Student(4, "Darshan", 56.96);
		Student s5 = new Student(5, "Liam", 67.98);
		Student s6 = new Student(6, "Louis", 68.56);
		Student s7 = new Student(7, "Harry", 94.33);
		Student s8 = new Student(8, "Niall", 75.45);
		Student s9 = new Student(9, "Jin", 85.34);

		ArrayList<Student> al1 = new ArrayList<Student>();
		al1.add(s1);
		al1.add(s2);
		al1.add(s3);

		ArrayList<Student> al2 = new ArrayList<Student>();
		al2.add(s4);
		al2.add(s5);
		al2.add(s6);

		ArrayList<Student> al3 = new ArrayList<Student>();
		al3.add(s7);
		al3.add(s8);
		al3.add(s9);

		LinkedHashMap<String, ArrayList<Student>> hm = new LinkedHashMap<String, ArrayList<Student>>();
		hm.put("First", al1);
		hm.put("Second", al2);
		hm.put("Third", al3);
		
		ArrayList<Student> al = hm.get("Third");
		Iterator<Student> it = al.iterator();
		while(it.hasNext()) {
			
			Student s = it.next();
			System.out.println("Id is: "+s.id);
			System.out.println("Name is: "+s.name);
			System.out.println("Percentage is: "+s.percentage);
			
		}

	}

}
