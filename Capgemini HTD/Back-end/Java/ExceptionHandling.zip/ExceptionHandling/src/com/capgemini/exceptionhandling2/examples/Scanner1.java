package com.capgemini.exceptionhandling2.examples;

import java.util.Scanner;

public class Scanner1 {

	public static void main(String[] args) {

		try(Scanner sc = new Scanner(System.in)){
			
			System.out.println("Enter the age: ");
			int age = sc.nextInt();
			
			System.out.println("Age is: "+age);
		}	
	}
}