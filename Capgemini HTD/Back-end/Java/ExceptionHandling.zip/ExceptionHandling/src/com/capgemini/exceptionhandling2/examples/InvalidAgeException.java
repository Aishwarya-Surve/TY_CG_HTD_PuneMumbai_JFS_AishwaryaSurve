package com.capgemini.exceptionhandling2.examples;

public class InvalidAgeException extends RuntimeException{
	
	private String msg = "Invalid age to proceed";
	
	@Override
	public String getMessage() {
		
		return msg;
	}

}
