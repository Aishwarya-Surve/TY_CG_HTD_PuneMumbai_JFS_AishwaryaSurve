package com.capgemini.exceptionhandling1.examples;

public class BMS {

	public static void main(String[] args) {
		
		System.out.println("Main() started");
		PVR p = new PVR();
		
		try {
		p.confirm();
		}
		
		catch (ArithmeticException e) {
			
			System.out.println("Exception caught at BMS");
		}
		
		System.out.println("Main() ended");
	}

}
