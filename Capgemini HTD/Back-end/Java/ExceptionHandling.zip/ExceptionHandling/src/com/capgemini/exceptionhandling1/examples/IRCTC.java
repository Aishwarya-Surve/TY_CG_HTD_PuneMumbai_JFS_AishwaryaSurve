package com.capgemini.exceptionhandling1.examples;

public class IRCTC {
	
	void confirm() {
		
		System.out.println("Confirm started");
		
		try {
		System.out.println(10/0);
		}
		
		catch(ArithmeticException e) {
			
			System.out.println("Exception caught by confirm()");
		}
		
		System.out.println("Confirm ended");
	}
	
	
	

}
