package com.capgemini.exceptionhandling1.examples;

public class TestPI {

	public static void main(String[] args) {

		System.out.println("Main started");
		
		Paytm p = new Paytm();
		
		try {
		p.book();
		}
		
		catch(ArithmeticException e) {
			
			System.out.println("Exception caught by main()");
		}
		
		System.out.println("Main ended");
	}

}
