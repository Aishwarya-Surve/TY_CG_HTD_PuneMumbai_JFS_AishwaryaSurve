package com.capgemini.exceptionhandling1.examples;

public class TestB {

	public static void main(String[] args) {

		System.out.println("Main() Started");

		try {

			System.out.println(10/0);
			System.out.println("Good Morning");
			System.out.println("Keep Smiling");
		}

		catch (ArithmeticException e) {

			System.out.println("Don't divide by zero");
		}

		System.out.println("Main() Ended");
		
	}

}
