package com.capgemini.exceptionhandling2.examples;

public class TestLimitAmount {

	public static void main(String[] args) {

		Amount a = new Amount();
		try {
			a.check(50000);
			System.out.println("Collect Cash");
		}
		
		catch(InvalidLimitException e) {
			e.printStackTrace();
		}
		
	}

}
