package com.capgemini.exceptionhandling2.examples;

public class TestInvalidAgeValidator {

	public static void main(String[] args) {
		
		Validator v = new Validator();
		
		try {
			v.verify(16);
			System.out.println("Welcome to Pub");
		}

		catch (InvalidAgeException in) {
			System.out.println(in.getMessage());
		}

	}

}
