package com.capgemini.exceptionhandling1.examples;

import java.io.File;
import java.io.IOException;

public class CheckerException {

	public static void main(String[] args) {

		System.out.println("Main Started");
		
		File f = new File("Aishwarya.txt");
		
		try {
			f.createNewFile();
			System.out.println("File Created");
		}
		
		catch (IOException e) {
			System.out.println("Sorry not able to create the file");
		}
		
		System.out.println("Main Ended");
		
	}

}
