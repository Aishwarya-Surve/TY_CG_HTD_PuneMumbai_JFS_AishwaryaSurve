package com.capgemini.exceptionhandling1.examples;

public class Paytm {
	
	void book() {
		
		System.out.println("Book started");
		
		IRCTC i = new IRCTC();
		
		try {
		i.confirm();
		}
		
		catch(ArithmeticException e) {
			
			System.out.println("Exception caught by book()");
		}
		
		System.out.println("Book ended");
	}
}
