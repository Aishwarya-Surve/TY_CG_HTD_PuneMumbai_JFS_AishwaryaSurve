package com.capgemini.exceptionhandling1.examples;

public class TryWithMultExcp {
	
	public static void main(String[] args) {

		System.out.println("Main() Started");

		int[] a = new int[4];
		
		String s = "Aishwarya";
		String s1 = null;

		try {

			System.out.println(s.length());
			System.out.println(s1.length());
			System.out.println(a[6]);
			System.out.println(10/0);
		}

		catch (ArrayIndexOutOfBoundsException | ArithmeticException | NullPointerException e) {

			e.printStackTrace();
		}

		System.out.println("Main() Ended");
	}


}
