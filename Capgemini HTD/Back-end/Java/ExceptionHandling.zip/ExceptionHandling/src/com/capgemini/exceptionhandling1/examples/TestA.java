package com.capgemini.exceptionhandling1.examples;

public class TestA {

	public static void main(String[] args) {

		System.out.println("Main() Started");

		int[] a = new int[4];

		try {

			System.out.println(a[6]);
		}

		catch (ArrayIndexOutOfBoundsException e) {

			System.out.println("Don't cross array boundary");
		}

		System.out.println("Main() Ended");
	}

}
