package com.capgemini.exceptionhandling1.examples;

public class Pen {

	public static void main(String[] args) {

		System.out.println("Main() Started");
		
		try {
			
			System.out.println(10/0);
			
		}
		
		catch(ArithmeticException e) {
			
			
			System.out.println("Please don't divide by zero");
		}
		
		System.out.println("Main() Ended");
		
	}

}
