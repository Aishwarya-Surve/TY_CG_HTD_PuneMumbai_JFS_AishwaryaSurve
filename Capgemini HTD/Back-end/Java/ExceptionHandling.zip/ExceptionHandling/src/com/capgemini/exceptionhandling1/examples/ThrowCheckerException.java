package com.capgemini.exceptionhandling1.examples;

import java.io.File;
import java.io.IOException;

public class ThrowCheckerException {

	public static void main(String[] args) throws IOException {

		File f = new File("Aishwarya.txt");
		
		f.createNewFile();
	}

}
