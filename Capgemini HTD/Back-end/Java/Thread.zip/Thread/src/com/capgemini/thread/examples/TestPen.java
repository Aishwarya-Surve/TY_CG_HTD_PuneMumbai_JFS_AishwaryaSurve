package com.capgemini.thread.examples;

public class TestPen {

	public static void main(String[] args) {

		System.out.println("****Main Started****");
		
		Pen p = new Pen();
		//p.setDaemon(true);
		p.start();
		
		Pen p1 = new Pen();
		//p1.setDaemon(true);
		p1.start();
		
		try {
			p1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("****Main Ended****");
		
	}

}
