package com.capgemini.thread.examples;

public class Paytm extends Thread{
	
	PVR ref;
	
	Paytm(PVR r){
		
		ref = r;
		
	}

	@Override
	public void run() {
		
		ref.confirm();
		
	}
}
