package com.capgemini.thread.examples;

public class TestPVRPaytm {

	public static void main(String[] args) {

		PVR a = new PVR();
		
		Paytm p1 = new Paytm(a);
		p1.start();
		
		Paytm p2 = new Paytm(a);
		p2.start();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		a.leaveMe();
		
	}

}
