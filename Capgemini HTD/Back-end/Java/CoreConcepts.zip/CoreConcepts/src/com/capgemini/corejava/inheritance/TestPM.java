package com.capgemini.corejava.inheritance;

public class TestPM {

	public static void main(String[] args) {
		
		Pen p = new Marker();
		Marker i = (Marker)p;
		
		i.cost = 100;
		i.write();
		i.size = 6;
		i.color();
		
	}

}
