package com.capgemini.corejava.methods;

public class Facebook {
	
	void login(long phone, String password) {
		System.out.println("Login by Mobile Number");
	}
	
	void login(String email, String password) {
		System.out.println("Login by Email");
	}

}
