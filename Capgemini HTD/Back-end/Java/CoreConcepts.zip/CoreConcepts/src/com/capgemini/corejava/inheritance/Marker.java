package com.capgemini.corejava.inheritance;

public class Marker extends Pen{
	double size;
	void color() {
		System.out.println("Black Marker");
		System.out.println("Size = "+size);
	}

}
