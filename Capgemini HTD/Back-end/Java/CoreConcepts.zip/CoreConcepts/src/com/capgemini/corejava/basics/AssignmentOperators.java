package com.capgemini.corejava.basics;

public class AssignmentOperators {
	
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		j +=i; //j = j+i
		System.out.println(j);
		j -=i; //j = j-i
		System.out.println(j);
		j *=i; //j = j*i
		System.out.println(j);
		j /=i; //j = j/i
		System.out.println(j);
		j %=i; //j = j%i
		System.out.println(j);
	}

}
