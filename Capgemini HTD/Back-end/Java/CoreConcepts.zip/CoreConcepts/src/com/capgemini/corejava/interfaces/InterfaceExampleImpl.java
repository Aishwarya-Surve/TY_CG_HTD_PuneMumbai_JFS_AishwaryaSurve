package com.capgemini.corejava.interfaces;

public class InterfaceExampleImpl implements InterfaceExample {

	@Override
	public void print() {
		System.out.println("Implemented print()");
	}

	// We can't override Static method in Interface
	/*
	 * @Override public static void show() {
	 * System.out.println("Static method of Interface"); }
	 */

	@Override
	public void display() {
		System.out.println("Implemented Display method of Interface");
	}

	public static void main(String[] args) {
		InterfaceExample ie = new InterfaceExampleImpl();
		ie.print();
		ie.display();
		ie.printNum();
		InterfaceExample.show();
	}

	@Override
	public void printNum() {
		System.out.println("1234");
	}

}
