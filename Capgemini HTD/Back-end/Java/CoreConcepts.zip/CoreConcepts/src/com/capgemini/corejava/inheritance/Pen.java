package com.capgemini.corejava.inheritance;

public class Pen {
	int cost;
	void write() {
		System.out.println("Pen");
		System.out.println("Cost = "+cost);
	}

}
