package com.capgemini.corejava.relationship;

public class Person {
	
	int i = 100;
	Marker m = new Marker();
	void walk() {
		
	}

}
