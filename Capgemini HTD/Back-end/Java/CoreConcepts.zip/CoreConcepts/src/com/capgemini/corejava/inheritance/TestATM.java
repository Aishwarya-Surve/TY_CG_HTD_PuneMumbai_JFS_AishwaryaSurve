package com.capgemini.corejava.inheritance;

public class TestATM {

	public static void main(String[] args) {
		
		ICICI i = new ICICI();
		SBI s = new SBI();
		HDFC h = new HDFC();
		
		Machine m = new Machine();
		m.slot(i);

	}

}
