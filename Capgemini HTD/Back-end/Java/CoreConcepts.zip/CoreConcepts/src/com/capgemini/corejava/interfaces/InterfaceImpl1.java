package com.capgemini.corejava.interfaces;

public abstract class InterfaceImpl1 implements InterfaceExample{
	

}
