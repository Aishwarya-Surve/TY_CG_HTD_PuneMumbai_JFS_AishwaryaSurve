package com.capgemini.corejava.inheritance;

public class ICICI implements ATM{

	public void validateCard() {
		System.out.println("....Connecting to ICICI");
	}

	public void getInfo() {
		System.out.println("Getting ICICI Account Information ");
	}
}
