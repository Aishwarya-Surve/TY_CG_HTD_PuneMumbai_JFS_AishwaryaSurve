package com.capgemini.corejava.inheritance;

public class Baby {
	
	void receive(Chips c) {
		c.open();
		c.eat();
	}
}
