package com.capgemini.corejava.basics;

public class LogicalOperators {
	
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		System.out.println(i>j && i<j);
		System.out.println(i>j || i<j);
	}

}
