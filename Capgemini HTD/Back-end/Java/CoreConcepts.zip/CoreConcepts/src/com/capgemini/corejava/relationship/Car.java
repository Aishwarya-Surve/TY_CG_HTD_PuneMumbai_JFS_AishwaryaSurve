package com.capgemini.corejava.relationship;

public class Car{
	
	static MusicSystem m = new MusicSystem();
}
