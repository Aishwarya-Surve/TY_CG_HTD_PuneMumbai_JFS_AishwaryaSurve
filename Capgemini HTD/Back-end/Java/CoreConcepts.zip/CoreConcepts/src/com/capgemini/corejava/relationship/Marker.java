package com.capgemini.corejava.relationship;

public class Marker {
	
	void write() {
		
	}
	
	void color() {
		
	}

}
