package com.capgemini.corejava.interfaces;

//@FunctionalInterface - We can only have one abstract method i functional interface
//Marker Interface - Interface doesn't have body
public interface InterfaceExample {
	
	public void print();
	public void printNum();
	
	default void display() {
		System.out.println("Default method of Interface");
	}
	
	public static void show() {
		System.out.println("Static method of Interface");
	}
	
}
