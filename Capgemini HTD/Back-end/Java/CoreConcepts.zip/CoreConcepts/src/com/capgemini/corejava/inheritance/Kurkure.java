package com.capgemini.corejava.inheritance;

public class Kurkure implements Chips{

	
	public void open() {
		System.out.println("Open Kurkure");
		
	}

	
	public void eat() {
		System.out.println("Eat Kurkure");
		
	}

}
