package com.capgemini.corejava.inheritance;

public class Driver extends Car{

	public static void main(String[] args) {
		Car c = new Car();
		System.out.println("Name : "+c.name);
		System.out.println("Color : "+c.color);
		System.out.println("Price : "+c.price);
	}

}
