package com.capgemini.corejava.relationship;

public class Test {
	// Has-a relationship
	public static void main(String[] args) {
		Person p = new Person();
		System.out.println(p.i);
		p.walk();
		p.m.color();
		p.m.write();
		
	}

}
