package com.capgemini.corejava.inheritance;

public class SBI implements ATM{
	
	public void validateCard() {
		System.out.println("....Connecting to SBI");
	}

	public void getInfo() {
		System.out.println("Getting ICICI Account SBI");
	}

}
