package com.capgemini.corejava.methods;

public class Train {
	
	void search(String name) {
		System.out.println("Search train by name");
	}
	
	void search(int num) {
		System.out.println("Search train by number");
	}

}
