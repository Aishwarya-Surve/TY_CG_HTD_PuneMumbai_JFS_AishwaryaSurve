package com.capgemini.corejava.relationship;

public class MusicSystem {
	void start() {
		System.out.println("Start Music");
	}
	void pause() {
		System.out.println("Pause Music");
	}
	void stop() {
		System.out.println("Stop Music");
	}
}
