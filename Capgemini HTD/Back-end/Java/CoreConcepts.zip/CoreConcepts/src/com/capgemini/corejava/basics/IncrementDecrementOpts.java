package com.capgemini.corejava.basics;

public class IncrementDecrementOpts {
	
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		
		i = ++i;
		System.out.println(i);
		
		int k = j++;
		System.out.println(k);
		System.out.println(j);
		
		i = --i;
		System.out.println(i);
		
		int l = j--;
		System.out.println(l);
		System.out.println(j);
	}

}
