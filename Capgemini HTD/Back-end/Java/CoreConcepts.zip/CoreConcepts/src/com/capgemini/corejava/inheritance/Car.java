package com.capgemini.corejava.inheritance;

public class Car {
	String name = "Mustang GT";
	String color = "black";
	double price = 500000.4556;

}
