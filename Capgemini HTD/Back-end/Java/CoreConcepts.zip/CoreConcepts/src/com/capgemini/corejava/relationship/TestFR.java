package com.capgemini.corejava.relationship;

public class TestFR {

	public static void main(String[] args) {
		System.out.println(Room.k);
		Room.f.on();
		Room.f.off();
	}
}
