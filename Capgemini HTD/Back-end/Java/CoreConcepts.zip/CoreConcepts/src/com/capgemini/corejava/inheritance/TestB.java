package com.capgemini.corejava.inheritance;

public class TestB {

	public static void main(String[] args) {
		Lays l = new Lays();
		
		Baby b = new Baby();
		b.receive(l);

	}

}
