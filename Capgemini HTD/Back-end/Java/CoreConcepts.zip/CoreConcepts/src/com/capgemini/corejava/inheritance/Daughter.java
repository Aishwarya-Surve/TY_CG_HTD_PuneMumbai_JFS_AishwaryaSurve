package com.capgemini.corejava.inheritance;

public class Daughter extends Father implements InterfaceExample{

	String dname = "Sansa";

	public static void main(String[] args) {
		Daughter dau = new Daughter();
		dau.printName();
		dau.display();
		dau.show();
		// Or - new Daughter().printName();
	}

	@Override
	public void printName() {
		System.out.println(dname + " " + fname + " " + lastname);
		super.printName();
	}
	
	@Override
	public void display() {
		System.out.println("Display method in daughter");
	}
	
	@Override
	public void show() {
		System.out.println("Show method in daughter");
	}

}
