package com.capgemini.corejava.methods;

public class MethodsExample {
	static int y=10;
	public static void main(String[] args) {
		print();
		int a = areaOfSquare(10);
		System.out.println("Area of Square = " + a); // System.out.println("Area of Square = "+areaOfSquare(10));
		// MethodsExample me = new MethodsExample()
		// int area = new MethodsExample().areaOfRect(2,5);
		System.out.println(new MethodsExample().areaOfRect(2, 5));
	}

	public static void print() {
		System.out.println("print() method");
	}

	public static int areaOfSquare(int side) {
		return side * side;
	}

	public  int areaOfRect(int length, int width) {
		return length * width;
	}

}
