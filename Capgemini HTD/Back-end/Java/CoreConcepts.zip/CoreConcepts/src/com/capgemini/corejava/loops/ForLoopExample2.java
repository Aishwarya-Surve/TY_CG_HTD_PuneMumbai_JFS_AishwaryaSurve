package com.capgemini.corejava.loops;

public class ForLoopExample2 {
	public static void main(String[] args) {
			int i = 4;
			if (i % 2 == 0) {
				for (int j = 1; j <= i; j++)
				System.out.println("j = "+j);
			} else {
				for (int k = 1; k <= i; k++)
				System.out.println("k = "+k);
			}
			System.out.println("Code outside for loop");
		}
}