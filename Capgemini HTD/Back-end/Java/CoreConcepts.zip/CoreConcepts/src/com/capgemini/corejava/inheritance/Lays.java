package com.capgemini.corejava.inheritance;

public class Lays implements Chips{

	
	public void open() {
		System.out.println("Open Lays");
		
	}

	
	public void eat() {
		System.out.println("Eat Lays");
		
	}

}
