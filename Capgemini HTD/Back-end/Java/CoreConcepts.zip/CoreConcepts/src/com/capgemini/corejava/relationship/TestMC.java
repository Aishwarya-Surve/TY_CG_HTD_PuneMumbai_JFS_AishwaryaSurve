package com.capgemini.corejava.relationship;

public class TestMC {

	public static void main(String[] args) {
		
		Car.m.start();
		Car.m.pause();
		Car.m.stop();
	}

}
