package com.capgemini.corejava.inheritance;

public interface ATM {
	void validateCard();
	void getInfo();

}
