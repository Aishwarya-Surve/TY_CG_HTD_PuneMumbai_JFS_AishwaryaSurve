package com.capgemini.corejava.inheritance;

public class Machine {
	
	void slot(ATM a) {
		
		a.validateCard();
		a.getInfo();
	}

}
