package com.capgemini.corejava.relationship;

public class Fan {
	void on() {
		System.out.println("I'm on method");
	}
	void off() {
		System.out.println("I'm off method");
	}

}
