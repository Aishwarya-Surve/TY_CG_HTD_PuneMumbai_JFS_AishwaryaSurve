package com.capgemini.corejava.methods;

public class TestTrain {

	public static void main(String[] args) {
		
		Train t = new Train();
		t.search(1234);
		t.search("bang-exp");
	}
}
