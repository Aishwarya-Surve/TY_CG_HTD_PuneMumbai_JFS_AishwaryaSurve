package com.capgemini.corejava.methods;

public class Demo {

	static MethodsExample me = new MethodsExample();

	public static void main(String[] args) {
		MethodsExample me1 = new MethodsExample();
		System.out.println(me); // Static
		System.out.println(me1); // Non-Static
		System.out.println(MethodsExample.areaOfSquare(6));
		System.out.println(me.areaOfRect(6, 7));
		System.out.println(me1.areaOfRect(6, 7));
		int r = me.y;
		System.out.println(r);
	}
}