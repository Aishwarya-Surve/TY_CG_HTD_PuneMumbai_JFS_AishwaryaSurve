package com.capgemini.corejava.inheritance;

public class Bingo implements Chips {

	
	public void open() {
		System.out.println("Open Bingo");
		
	}

	
	public void eat() {
		System.out.println("Eat Bingo");
		
	}

}
