package com.capgemini.beanclass.examples;

public class TestBus {

	public static void main(String[] args) {

		Bus b = new Bus("Navlai", 100);
		
		System.out.println("Name: "+b.getName());
		System.out.println("Seats: "+b.getSeats());
	}

}
