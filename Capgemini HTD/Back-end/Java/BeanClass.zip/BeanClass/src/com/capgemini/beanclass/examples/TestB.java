package com.capgemini.beanclass.examples;

public class TestB {

	public static void main(String[] args) {

		Car c = new Car(200000, "Benz");
		
		System.out.println("Car Cost: "+c.getCost());
		System.out.println("Car Cost: "+c.getName());
		
		
	}

}
