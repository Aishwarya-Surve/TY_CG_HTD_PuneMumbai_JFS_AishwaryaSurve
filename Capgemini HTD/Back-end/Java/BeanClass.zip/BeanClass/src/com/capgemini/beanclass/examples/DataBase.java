package com.capgemini.beanclass.examples;

public class DataBase {
	
	void receive(Student t) {
		
		System.out.println("*******DataBase*******");
		System.out.println("Student ID is: "+t.getId());
		System.out.println("Student Name is: "+t.getName());
		System.out.println("Student Height is: "+t.getHeight());
		
	}
	
	void receive(Employee e) {
		
		
		
	}

}
