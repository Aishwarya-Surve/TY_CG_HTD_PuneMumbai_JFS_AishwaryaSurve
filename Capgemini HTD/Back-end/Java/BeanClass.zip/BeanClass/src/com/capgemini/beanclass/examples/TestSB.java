package com.capgemini.beanclass.examples;

public class TestSB {

	public static void main(String[] args) {

		Student s = new Student();
		
		s.setId(10);
		s.setName("Aishwarya");
		s.setHeight(5.6);
		
		DataBase db = new DataBase();
		db.receive(s);
		
	}

}
