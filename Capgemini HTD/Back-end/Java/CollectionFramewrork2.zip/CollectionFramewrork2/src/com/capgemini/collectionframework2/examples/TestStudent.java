package com.capgemini.collectionframework2.examples;

import java.util.ArrayList;

public class TestStudent {

	public static void main(String[] args) {

		ArrayList<Student> al = new ArrayList<Student>();

		Student s1 = new Student(1, "Aishwarya", 90);
		Student s2 = new Student(2, "Taehyung", 95);
		Student s3 = new Student(3, "Zayn", 88);
		Student s4 = new Student(4, "Darshan", 70);
		Student s5 = new Student(5, "Johny", 34);

		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		StudentHelper h = new StudentHelper();
		h.display(al);
		h.onlyPass(al);
		h.onlyDistinction(al);
	}
}
