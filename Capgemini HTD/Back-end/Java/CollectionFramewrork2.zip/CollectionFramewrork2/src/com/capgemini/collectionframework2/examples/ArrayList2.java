package com.capgemini.collectionframework2.examples;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayList2 {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add('A');
		al.add('T');
		al.add('Z');
		al.add('D');
		System.out.println("Before -------> " + al);

		Collections.sort(al);

		System.out.println("After -------> " + al);

	}

}
