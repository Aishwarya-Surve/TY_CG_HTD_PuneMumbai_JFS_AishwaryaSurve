package com.capgemini.collectionframework2.examples;

public class MyStudentApp {

}
