package com.capgemini.collectionframework2.examples;

import java.util.Collections;
import java.util.LinkedList;

public class LinkedList1 {

	public static void main(String[] args) {

		LinkedList<Double> li = new LinkedList<Double>();

		li.add(3.6);
		li.add(2.4);
		li.add(4.7);
		li.add(1.6);

		System.out.println("Before -------> " + li);

		li.push(89.82); // add the object in 1st index

		Collections.shuffle(li);

		System.out.println("After -------> " + li);

		for (int i = 0; i < li.size(); i++) {

			Double r = li.get(i);
			System.out.println(r);

		}

	}

}
