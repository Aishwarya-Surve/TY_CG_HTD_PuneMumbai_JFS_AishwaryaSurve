package com.capgemini.collectionframework2.examples;

import java.util.ArrayList;
import java.util.Iterator;

public class StudentHelper {
	void display(ArrayList<Student> k) {

		for (Student s : k) {

			System.out.println("ID: " + s.id);
			System.out.println("Name: " + s.name);
			System.out.println("Percentage: " + s.percentage);

			System.out.println("**************************");

		}

	}

	void onlyPass(ArrayList<Student> k) {

		Iterator<Student> it = k.iterator();

		while (it.hasNext()) {
			
			Student s = it.next();
			
			if(s.percentage >= 35) {
			System.out.println("ID: " + s.id);
			System.out.println("Name: " + s.name);
			System.out.println("Percentage: " + s.percentage);

			System.out.println("**************************");
			
			}
			

		}

	}
	
	void onlyDistinction(ArrayList<Student> k) {
		
		Iterator<Student> it = k.iterator();

		while (it.hasNext()) {
			
			Student s = it.next();
			
			if(s.percentage >= 75) {
			System.out.println("ID: " + s.id);
			System.out.println("Name: " + s.name);
			System.out.println("Percentage: " + s.percentage);

			System.out.println("**************************");
			
			}
			

		}
		
	}
}
