package com.capgemini.collectionframework2.examples;

public class TestStudent2 {

	public static void main(String[] args) {

		
		
	}

}
