package com.capgemini.stream.examples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayList6 {

	public static void main(String[] args) {

		ArrayList<Employee> al = new ArrayList<Employee>();
		
		
		List<Employee> li = al.stream().sorted().collect(Collectors.toList());
		
		
	}

}
