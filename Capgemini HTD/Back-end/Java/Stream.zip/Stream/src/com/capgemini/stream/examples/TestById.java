package com.capgemini.stream.examples;

import java.util.Comparator;
import java.util.TreeSet;

public class TestById {

	public static void main(String[] args) {

		Comparator<Employee> comp = (e1, e2) -> {
			
			if(e1.id > e2.id) {
				
				return 1;
				
			}
			else if(e1.id < e2.id ) {
				
				return -1;
				
			}
			else {
				
				return 0;
				
			}
			
		};
		
		TreeSet<Employee> ts = new TreeSet<Employee>(comp);
		
		Employee e1 = new Employee(1, "Aishwarya", 5.6);
		Employee e2 = new Employee(2, "Taehyung", 6.2);
		
		ts.add(e1);
		ts.add(e2);
		
		for(Employee e : ts) {
			System.out.println("Id: "+e.id);
			System.out.println("Name: "+e.name);
			System.out.println("Height: "+e.height);
			
		}
		
	}
	
}
