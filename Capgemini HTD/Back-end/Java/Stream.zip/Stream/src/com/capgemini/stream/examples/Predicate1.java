package com.capgemini.stream.examples;

import java.util.function.Predicate;

public class Predicate1 {

	public static void main(String[] args) {

		//Predicate<Integer> p = i -> i%2 ==0;
		
		Predicate<Integer> p =i -> {
			
			if(i%2 == 0) {
				
				return true;
				
			}
			else {
				
				return false;
				
			}
			
		};
		
		boolean res = p.test(15);
		System.out.println("Result is "+res);
	}

}
