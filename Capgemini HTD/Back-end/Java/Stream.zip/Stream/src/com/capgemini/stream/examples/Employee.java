package com.capgemini.stream.examples;

public class Employee {
	
	 int id;
	 String name;
	 double height;
	 
	public Employee(int id, String name, double height) {
		super();
		this.id = id;
		this.name = name;
		this.height = height;
	}
	
}
