package com.capgemini.stream.examples;

import java.util.function.Function;

public class Funtion1 {

	public static void main(String[] args) {
		Function<Integer, Integer> f = i -> i * i;
		int ans = f.apply(6);
		System.out.println("Result is: " + ans);
	}

}
