package com.capgemini.stream.examples;

import java.util.function.Predicate;


public class Predicate2 {
	
	public static void main(String[] args) {

		//Predicate<Student> p = i -> i%2 ==0;
		
		Predicate<Student> p =i -> {
			
			if(i.percentage >= 35 ) {
				
				return true;
				
			}
			else {
				
				return false;
				
			}
			
		};
		
		Student s1 = new Student(1, "Aishwarya", 65.4);
		boolean res = p.test(s1);
		System.out.println("Result is "+res);
	}


}
