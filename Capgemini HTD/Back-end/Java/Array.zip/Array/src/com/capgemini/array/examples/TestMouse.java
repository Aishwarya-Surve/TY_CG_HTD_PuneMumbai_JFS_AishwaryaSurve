package com.capgemini.array.examples;

public class TestMouse {

	public static void main(String[] args) {

		Mouse m = new Mouse();
		
		double[] d = {10.1,20.2,30.3,40.4};
		
		m.walk(d);
		
		System.out.println("-------------------------");
		
		int[] e = {10,20,30,40};
		
		m.run(e);
		
	}

}
