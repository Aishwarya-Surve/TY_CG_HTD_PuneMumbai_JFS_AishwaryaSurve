package com.capgemini.array.examples;

public class TestC {

	public static void main(String[] args) {

		int[] d = new int[4];

		d[0] = 10;
		d[1] = 20;
		d[2] = 30;
		d[3] = 40;

		for (int i = 0; i < d.length; i++) {
			System.out.println(d[i]);
		}
		
		System.out.println("Size of array = "+d.length);
	}
}
