package com.capgemini.array.examples;

public class TestJ {
	
static void receive(String i[]) {
		
		receive(i);
	}
	
	public static void main(String[] args) {

		String a[]= {"Aishwarya", "Taehyung", "Zayn", "Darshan"};
		
		for(String i : a) {
			
			System.out.println(i);
			
		}
	}


}
