package com.capgemini.array.examples;

public class TestD {

	public static void main(String[] args) {

		int a[]= {10,20,30,40,50,60};
		
		for(int i = 0; i<a.length; i++) {
			
			System.out.println(a[i]);
			
		}
	}

}
