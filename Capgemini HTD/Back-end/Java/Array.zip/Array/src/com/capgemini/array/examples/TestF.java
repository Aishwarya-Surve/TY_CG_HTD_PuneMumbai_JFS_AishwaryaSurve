package com.capgemini.array.examples;

public class TestF {
	
	public static void main(String[] args) {

		double d[] = {1.1,2.2,3.3,4.4,5.5,6.6};
		
		for(double a : d) {
			
			System.out.println(a);
			
		}
		
	}

}
