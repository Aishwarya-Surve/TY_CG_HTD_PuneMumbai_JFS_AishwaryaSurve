package com.capgemini.array.examples;

public class TestB {

	public static void main(String[] args) {

		String[] s = new String[4];

		s[0] = "Aishwarya";
		s[1] = "Taehyung";
		s[2] = "Zayn";
		s[3] = "Darshan";

		for (int i = 0; i <= 3; i++) {
			System.out.println(s[i]);
		}
	}
}