package com.capgemini.array.examples;

interface GMInterface{
	
	void gm();
	
}

public class GM{ 

	public static void main(String[] args) {

	
		GMInterface g = () -> System.out.println("Good Morning");
		
		g.gm();
	}

}
