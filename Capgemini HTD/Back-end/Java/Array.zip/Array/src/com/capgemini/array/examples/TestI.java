package com.capgemini.array.examples;

public class TestI {
	
static void receive(double i[]) {
		
		receive(i);
	}
	
	public static void main(String[] args) {

		double a[]= {10.1,20.2,30.3,40.4,50.5,60.6};
		
		for(double i : a) {
			
			System.out.println(i);
			
		}
	}


}
