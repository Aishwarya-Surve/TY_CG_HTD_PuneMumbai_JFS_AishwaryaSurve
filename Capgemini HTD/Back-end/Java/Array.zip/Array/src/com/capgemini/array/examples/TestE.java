package com.capgemini.array.examples;

public class TestE {

	public static void main(String[] args) {

		char ch[] = {'A', 'B', 'C', 'D', 'E', 'F'};
		
		for(char a : ch) {
			
			System.out.println(a);
			
		}
		
	}

}
