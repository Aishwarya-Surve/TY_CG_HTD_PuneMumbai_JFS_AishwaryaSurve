package com.capgemini.array.examples;

public class TestK {

	public static void main(String[] args) {

		Student s[] = new Student[4];

		Student s1 = new Student(1, "Aishwarya", 90);
		Student s2 = new Student(2, "Taehyung", 90);
		Student s3 = new Student(3, "Zayn", 90);
		Student s4 = new Student(4, "Darshan", 90);

		s[0] = s1;
		s[1] = s2;
		s[2] = s3;
		s[3] = s4;

		receive(s);

	}

	static void receive(Student[] ar) {

		for (Student k : ar) {
			System.out.println(k.id);
			System.out.println(k.name);
			System.out.println(k.percentage);

		}

	}
}
