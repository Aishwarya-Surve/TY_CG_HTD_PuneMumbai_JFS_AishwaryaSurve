package com.capgemini.array.examples;

interface Area {

	double ar(double pi, double r);
}

public class AreaOfCircle {

	public static void main(String[] args) {

		Area s = (pi, r) -> pi * r * r;
		double j = s.ar(3.142, 4);
		System.out.println("Square of given number is " + j);

	}

}
