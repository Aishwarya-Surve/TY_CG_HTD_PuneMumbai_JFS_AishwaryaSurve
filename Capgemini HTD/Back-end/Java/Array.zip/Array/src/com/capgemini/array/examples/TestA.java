package com.capgemini.array.examples;

public class TestA {
	
	public static void main(String[] args) {
		
		double[] d = new double[4];
		
		d[0] = 10;
		d[1] = 20;
		d[2] = 30;
		d[3] = 40;
		
		for(int i=0; i<=3; i++) {
			System.out.println(d[i]);
		}
		
	}

}
