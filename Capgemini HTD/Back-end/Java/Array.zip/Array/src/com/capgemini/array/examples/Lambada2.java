package com.capgemini.array.examples;

interface Square{
	
	int sqr(int a);
}


public class Lambada2 {

	public static void main(String[] args) {

		Square s = (a) -> a*a;
		int j = s.sqr(4);
		System.out.println("Square of given number is "+j);
		
	}

}
