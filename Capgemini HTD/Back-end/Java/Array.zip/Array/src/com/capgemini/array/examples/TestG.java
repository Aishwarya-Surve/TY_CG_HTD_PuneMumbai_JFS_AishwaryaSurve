package com.capgemini.array.examples;

public class TestG {

	public static void main(String[] args) {

		double[] a = new double[4];
		
		a[2] = 100;

		for(double i : a) {
			
			System.out.println(i);
			
		}
		
	}

}
