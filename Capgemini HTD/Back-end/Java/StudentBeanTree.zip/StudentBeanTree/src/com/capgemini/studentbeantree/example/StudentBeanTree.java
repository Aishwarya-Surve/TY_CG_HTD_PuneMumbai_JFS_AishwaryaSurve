package com.capgemini.studentbeantree.example;

public class StudentBeanTree {

	private int id;
	private String name;
	private double percentage;
	private char gender;

	public void setId(int id) {
		this.id = id;

	}

	public int getId() {
		return id;

	}

	public void setName(String name) {
		this.name = name;

	}

	public String getName() {
		return name;

	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;

	}

	public double getPercentage() {
		return percentage;

	}

	public void setGender(char gender) {
		this.gender = gender;

	}

	public char getGender() {
		return gender;

	}

}
