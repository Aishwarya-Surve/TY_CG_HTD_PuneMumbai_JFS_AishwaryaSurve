package com.capgemini.studentbeantree.example;

import java.util.Comparator;

public class ByPercentage implements Comparator<StudentBeanTree> {

	@Override
	public int compare(StudentBeanTree o1, StudentBeanTree o2) {

		if (o1.getPercentage() > o2.getPercentage()) {
			return 1;
		} else if (o1.getPercentage() < o2.getPercentage()) {
			return -1;
		} else {
			return 0;
		}
	}

}
