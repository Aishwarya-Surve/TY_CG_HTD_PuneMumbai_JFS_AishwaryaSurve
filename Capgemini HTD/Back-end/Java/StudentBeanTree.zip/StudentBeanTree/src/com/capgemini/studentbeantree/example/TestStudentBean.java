package com.capgemini.studentbeantree.example;

import java.util.TreeSet;

public class TestStudentBean {

	public static void main(String[] args) {

		ById bi = new ById();
		ByName bn = new ByName();
		ByPercentage bp = new ByPercentage();
		
		

		TreeSet<StudentBeanTree> ts = new TreeSet<StudentBeanTree>(bi);
		StudentBeanTree sbt1 = new StudentBeanTree();
		sbt1.setId(101);
		sbt1.setName("Aishwarya");
		sbt1.setPercentage(89.82);
		sbt1.setGender('F');

		StudentBeanTree sbt2 = new StudentBeanTree();
		sbt2.setId(102);
		sbt2.setName("Taehyung");
		sbt2.setPercentage(82.56);
		sbt2.setGender('M');

		StudentBeanTree sbt3 = new StudentBeanTree();
		sbt3.setId(103);
		sbt3.setName("Zayn");
		sbt3.setPercentage(86);
		sbt3.setGender('M');

		StudentBeanTree sbt4 = new StudentBeanTree();
		sbt4.setId(104);
		sbt4.setName("Darshan");
		sbt4.setPercentage(88);
		sbt4.setGender('M');

		StudentBeanTree sbt5 = new StudentBeanTree();
		sbt5.setId(105);
		sbt5.setName("Johny");
		sbt5.setPercentage(75);
		sbt5.setGender('M');

		ts.add(sbt1);
		ts.add(sbt2);
		ts.add(sbt3);
		ts.add(sbt4);
		ts.add(sbt5);

		for (StudentBeanTree sbt : ts) {
			System.out.println("ID: " + sbt.getId());
			System.out.println("Name: " + sbt.getName());
			System.out.println("Percentage: " + sbt.getPercentage());
			System.out.println("Gender: " + sbt.getGender());
			System.out.println("********************");
		}
	}

}
