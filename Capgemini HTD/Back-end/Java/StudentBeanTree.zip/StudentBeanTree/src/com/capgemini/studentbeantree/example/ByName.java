package com.capgemini.studentbeantree.example;

import java.util.Comparator;

public class ByName implements Comparator<StudentBeanTree> {

	@Override
	public int compare(StudentBeanTree o1, StudentBeanTree o2) {

		return o1.getName().compareTo(o2.getName());
	}

}
