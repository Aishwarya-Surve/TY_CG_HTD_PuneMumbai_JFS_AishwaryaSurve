package com.capgemini.stringexample.one;

public class Parsing {

	public static void main(String[] args) {

		String k = "90";
		String p = "50";
		
		int i = Integer.parseInt(k);
		int j = Integer.parseInt(p);
		
		System.out.println("k + p = "+(i+j));
		
	}

}
