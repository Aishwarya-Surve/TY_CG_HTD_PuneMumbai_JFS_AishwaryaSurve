package com.capgemini.stringexample.one;

public class TestA {

	public static void main(String[] args) {

		String a = "Taehyung";

		String b = "Aishwarya";
		
		String c = "Taehyung";
		

		System.out.println("a is " + a);
		System.out.println("b is " + b);

	}

}
