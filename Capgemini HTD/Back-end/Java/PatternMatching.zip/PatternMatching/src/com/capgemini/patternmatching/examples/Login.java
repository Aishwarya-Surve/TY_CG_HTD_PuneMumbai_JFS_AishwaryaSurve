package com.capgemini.patternmatching.examples;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login {

	static Pattern pattern;
	static Matcher matcher;

	public static void main(String[] args) {

		pattern = Pattern.compile("\\d"); // for single digit
		matcher = pattern.matcher("6");
		System.out.println("pattern \\d: " + matcher.matches());

		pattern = Pattern.compile("\\d+"); // for multiple digits
		matcher = pattern.matcher("1234567890");
		System.out.println("pattern \\d: " + matcher.matches());

		pattern = Pattern.compile("\\D"); // for single character
		matcher = pattern.matcher("A");
		System.out.println("pattern \\D: " + matcher.matches());

		pattern = Pattern.compile("\\D+"); // for multiple characters
		matcher = pattern.matcher("Aishwarya");
		System.out.println("pattern \\D: " + matcher.matches());

		pattern = Pattern.compile("\\w"); // for single character
		matcher = pattern.matcher("A");
		System.out.println("pattern \\w: " + matcher.matches());

		pattern = Pattern.compile("\\w+"); // for multiple characters
		matcher = pattern.matcher("Aishwarya");
		System.out.println("pattern \\w: " + matcher.matches());
		
		pattern = Pattern.compile("\\W"); // for single digit
		matcher = pattern.matcher("1");
		System.out.println("pattern \\W: " + matcher.matches());
		
		pattern = Pattern.compile("\\W+"); // for multiple digits
		matcher = pattern.matcher("1234");
		System.out.println("pattern \\W: " + matcher.matches());
	}

}
