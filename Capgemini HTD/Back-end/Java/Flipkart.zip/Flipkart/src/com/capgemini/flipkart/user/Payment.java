package com.capgemini.flipkart.user;

public class Payment {

}
