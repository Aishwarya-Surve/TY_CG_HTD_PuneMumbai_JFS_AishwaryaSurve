package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add(23);
		al.add("Aishwarya");
		al.add(4.4);
		al.add('Z');

		for (int i = 0; i < 4; i++) {

			Object r = al.get(i);
			System.out.println(r);

		}
	}

}
