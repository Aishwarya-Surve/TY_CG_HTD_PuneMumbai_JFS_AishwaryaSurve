package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class ArrayList5 {
	
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();

		al.add(23);
		al.add("Aishwarya");
		al.add(4.4);
		al.add('Z');
		
		System.out.println(al);
	}

}
