package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedList2 {

	public static void main(String[] args) {

		LinkedList<String> li = new LinkedList<String>();
		li.add("Aishwarya");
		li.add("Zayn");
		li.add("Taehyung");
		li.add("Darshan");

		System.out.println("******For Loop******");
		for (int i = 0; i < 4; i++) {

			String r = li.get(i);
			System.out.println(r);

		}

		System.out.println("******For-Each Loop******");
		for (String r : li) {

			System.out.println(r);

		}

		System.out.println("******Iterator******");
		Iterator<String> it = li.iterator();

		while (it.hasNext()) {

			String r = it.next();
			System.out.println(r);

		}

		System.out.println("******ListIterator******");
		ListIterator<String> lt = li.listIterator();

		System.out.println("-------------> Forward");
		while (lt.hasNext()) {

			String r = lt.next();
			System.out.println(r);

		}

		System.out.println("<------------- Backward");
		while (lt.hasPrevious()) {

			String r = lt.previous();
			System.out.println(r);

		}
	}

}
