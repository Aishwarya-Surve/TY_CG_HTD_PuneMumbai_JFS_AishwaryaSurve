package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayList11 {

	public static void main(String[] args) {

		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.2);
		al.add(4.4);
		al.add(6.6);
		al.add(8.8);

		ListIterator<Double> lt = al.listIterator();

		System.out.println("-------------> Forward");
		while (lt.hasNext()) {
			Double r = lt.next();
			System.out.println(r);
		}
		System.out.println("<------------- Backward");
		while (lt.hasPrevious()) {
			Double r = lt.previous();
			System.out.println(r);
		}
	}
}
