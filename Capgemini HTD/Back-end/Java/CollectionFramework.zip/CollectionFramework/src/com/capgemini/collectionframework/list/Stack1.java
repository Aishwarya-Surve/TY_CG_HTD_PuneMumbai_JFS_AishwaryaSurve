package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Stack;

public class Stack1 {

	public static void main(String[] args) {

		Stack<String> v = new Stack();
		v.add("Aishwarya");
		v.add("Taehyung");
		v.add("Zayn");
		v.add("Darshan");

		System.out.println("******For Loop******");
		
		for (int i = 0; i < 4; i++) {

			String r = v.get(i);
			System.out.println(r);

		}

		System.out.println("******For-Each Loop******");
		
		for (String r : v) {

			System.out.println(r);

		}

		System.out.println("******Iterator******");
		
		Iterator<String> it = v.iterator();

		while (it.hasNext()) {

			String r = it.next();
			System.out.println(r);

		}

		System.out.println("******ListIterator******");
		
		ListIterator<String> lt = v.listIterator();

		System.out.println("-------------> Forward");
		while (lt.hasNext()) {

			String r = lt.next();
			System.out.println(r);

		}

		System.out.println("<------------- Backward");
		while (lt.hasPrevious()) {

			String r = lt.previous();
			System.out.println(r);

		}
	}

}
