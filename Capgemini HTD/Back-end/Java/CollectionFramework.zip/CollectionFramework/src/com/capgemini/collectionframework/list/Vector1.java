package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Vector;

public class Vector1 {

	public static void main(String[] args) {

		Vector<Character> v = new Vector();
		v.add('A');
		v.add('T');
		v.add('Z');
		v.add('D');

		System.out.println("******For Loop******");
		
		for (int i = 0; i < 4; i++) {

			Character r = v.get(i);
			System.out.println(r);

		}

		System.out.println("******For-Each Loop******");
		
		for (Character r : v) {

			System.out.println(r);

		}

		System.out.println("******Iterator******");
		
		Iterator<Character> it = v.iterator();

		while (it.hasNext()) {

			Character r = it.next();
			System.out.println(r);

		}

		System.out.println("******ListIterator******");
		
		ListIterator<Character> lt = v.listIterator();

		System.out.println("-------------> Forward");
		while (lt.hasNext()) {

			Character r = lt.next();
			System.out.println(r);

		}

		System.out.println("<------------- Backward");
		while (lt.hasPrevious()) {

			Character r = lt.previous();
			System.out.println(r);

		}
	}

}
