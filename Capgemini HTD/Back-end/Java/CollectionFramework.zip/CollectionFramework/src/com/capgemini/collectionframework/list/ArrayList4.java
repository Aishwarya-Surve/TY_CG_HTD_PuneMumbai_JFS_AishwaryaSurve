package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayList4 {
	
	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add(23);
		al.add("Aishwarya");
		al.add(4.4);
		al.add('Z');

		ListIterator lt = al.listIterator();
		
		System.out.println("-------------> Forward");
		while(lt.hasNext()) {
			
			Object r =lt.next();
			System.out.println(r);
			
		}
		
		System.out.println("<------------- Backward");
		while(lt.hasPrevious()) {
			
			Object r =lt.previous();
			System.out.println(r);
			
		}
	}

}
