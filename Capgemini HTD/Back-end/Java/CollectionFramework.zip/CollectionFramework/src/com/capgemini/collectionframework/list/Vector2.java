package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class Vector2 {

	public static void main(String[] args) {

		Vector v = new Vector();
		v.add("Aishwarya");
		v.add('T');
		v.add(4);
		v.add(8.8);

		System.out.println("******For Loop******");
		
		for (int i = 0; i < 4; i++) {

			Object r = v.get(i);
			System.out.println(r);

		}

		System.out.println("******For-Each Loop******");
		
		for (Object r : v) {

			System.out.println(r);

		}

		System.out.println("******Iterator******");
		
		Iterator it = v.iterator();

		while (it.hasNext()) {

			Object r = it.next();
			System.out.println(r);

		}

		System.out.println("******ListIterator******");
		
		ListIterator lt = v.listIterator();

		System.out.println("-------------> Forward");
		while (lt.hasNext()) {

			Object r = lt.next();
			System.out.println(r);

		}

		System.out.println("<------------- Backward");
		while (lt.hasPrevious()) {

			Object r = lt.previous();
			System.out.println(r);

		}
	}

}
