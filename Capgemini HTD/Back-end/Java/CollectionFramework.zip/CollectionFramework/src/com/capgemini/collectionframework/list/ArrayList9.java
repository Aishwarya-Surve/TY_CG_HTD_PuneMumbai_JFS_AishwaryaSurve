package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class ArrayList9 {
	
	public static void main(String[] args) {

		ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.2);
		al.add(4.4);
		al.add(6.6);
		al.add(8.8);

		for (Double r : al) {

			System.out.println(r);

		}

	}

}
