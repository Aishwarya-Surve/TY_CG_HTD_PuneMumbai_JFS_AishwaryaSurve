package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList7 {
	
	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add("Taehyung");
		al.add(23);
		al.add('A');
		al.add(8.8);

		Iterator it = al.iterator();
		
		while(it.hasNext()) {
			
			Object r =it.next();
			System.out.println(r);
			
		}
	}

}
