package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class ArrayList6 {

	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();

		al.add("Zayn");
		al.add(1);
		al.add(6.6);
		al.add('A');
		
		for(Object r : al) {
			
			System.out.println(r);
			
		}

	}

}
