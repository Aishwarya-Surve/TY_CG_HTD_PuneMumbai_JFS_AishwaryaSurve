package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class ArrayList2 {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add(23);
		al.add("Aishwarya");
		al.add(4.4);
		al.add('Z');

		for(Object r : al) {
			
			System.out.println(r);
			
		}
	}

}
