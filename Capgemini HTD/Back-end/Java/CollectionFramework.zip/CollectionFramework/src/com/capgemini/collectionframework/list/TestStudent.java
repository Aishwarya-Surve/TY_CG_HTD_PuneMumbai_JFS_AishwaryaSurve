package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestStudent {

	public static void main(String[] args) {

		
		ArrayList<Student> al = new ArrayList<Student>();
		
		Student s1 = new Student(1, "Aishwarya", 90);
		Student s2 = new Student(2, "Taehyung", 95);
		Student s3 = new Student(3, "Zayn", 88);
		Student s4 = new Student(4, "Darshan", 86);
		Student s5 = new Student(5, "Johny", 80);
		
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		for(int i = 0;i<5;i++) {
			
			Student s = al.get(i);
			System.out.println("ID: "+s.id);
			System.out.println("Name: "+s.name);
			System.out.println("Percentage: "+s.percentage);
			
			System.out.println("**************************");
			
		}
		
		
	}

}
