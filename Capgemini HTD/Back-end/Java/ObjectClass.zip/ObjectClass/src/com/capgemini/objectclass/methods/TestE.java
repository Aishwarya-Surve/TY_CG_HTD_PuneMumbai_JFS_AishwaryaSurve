package com.capgemini.objectclass.methods;

public class TestE {

	public static void main(String[] args) {

		Cow c = new Cow();
		c.id = 1;
		c.name = "Ganga";

		Cow d = new Cow();
		c.id = 2;
		c.name = "Tunga";

		Cow e = new Cow();
		c.id = 1;
		c.name = "Ganga";
		
		boolean result = c.equals(e);
		System.out.println(result);

	}

}
