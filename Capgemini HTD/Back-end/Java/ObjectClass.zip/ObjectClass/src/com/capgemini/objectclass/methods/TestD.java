package com.capgemini.objectclass.methods;

public class TestD {

	public static void main(String[] args) {
		Employee e = new Employee(1,"Aishwarya",10000,'f');
		System.out.println(e);
		
	}

}
