package com.capgemini.objectclass.methods;

public class TestB {

	public static void main(String[] args) {

		Pen  p = new Pen();
		
		int add = p.hashCode();
		
		System.out.println("Address is "+add);
		
		String str = p.toString(); //Or System.out.println(p); - toString() will be automatically called
		System.out.println(str );
		
	}

}
