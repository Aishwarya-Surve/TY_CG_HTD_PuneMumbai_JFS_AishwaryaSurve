package com.capgemini.objectclass.methods;

public class Customer {
	
	public static void main(String[] args) {
		
		Product p = new Product();
		p.id = 10;
		p.name = "t=shirt";
		p.type = "Clothing";
		p.cost = 2000;
		p.brand = "Puma";
		
		System.out.println(p);
		
		
	}

}
