package com.capgemini.objectclass.methods;

public class TestC {

	public static void main(String[] args) {

		Student s = new Student(1,"Aishwarya",67.5);
		Student s1 = new Student(2,"Shruti",71);
		
		System.out.println(s);
		System.out.println(s1);
	}

}
