package com.capgemini.seleniumproject.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "Features", glue = {"com.capgemini.seleniumproject.stepdefination.LoginStepDefination"})
public class BDDRunner extends AbstractTestNGCucumberTests{

}
