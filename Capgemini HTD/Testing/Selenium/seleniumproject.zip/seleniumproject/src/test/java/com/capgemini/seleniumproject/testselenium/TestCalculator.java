package com.capgemini.seleniumproject.testselenium;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.seleniumproject.Calculator;

public class TestCalculator {

	@Test
	public void add() {
		Calculator c = new Calculator();
		int a = 20;
		int b = 10;
		int expected = 30;
		int actual = c.add(a,b);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void sub() {
		Calculator c = new Calculator();
		int a = 20;
		int b = 10;
		int expected = 10;
		int actual = c.sub(a,b);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void mul() {
		Calculator c = new Calculator();
		int a = 20;
		int b = 10;
		int expected = 200;
		int actual = c.mul(a,b);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void div() {
		Calculator c = new Calculator();
		int a = 20;
		int b = 10;
		int expected = 2;
		int actual = c.div(a,b);
		Assert.assertEquals(expected, actual);
	}
	
}
