package com.capgemini.seleniumproject.testselenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestSelenium3 {

	static {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
	}

	public static void main(String[] args) {

		// Open the browser
		WebDriver driver = new ChromeDriver();
		WebElement element = null;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Enter the URL
		driver.get("https://www.gmail.com");
		// Enter the valid username
		driver.findElement(By.id("identifierId")).sendKeys("mybarbiedoll1111@gmail.com");
		// Click on next
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		// Enter the valid password
		driver.findElement(By.name("password")).sendKeys("mybarbie@123");
		// Login
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		// Compose
		driver.findElement(By.xpath("//*[@role='button' and text()='Compose']")).click();
		driver.findElement(By.xpath("//textarea[@name='to']")).sendKeys("hdurmale@gmail.com");
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("Capgemini");
		element = driver.findElement(By.xpath("//div[@class='Ar Au']//div"));
		element.click();
		element.sendKeys("Hi Harshini");
		driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
		
	}
}