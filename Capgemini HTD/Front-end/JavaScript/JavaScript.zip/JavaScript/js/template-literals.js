var myString = `BTS (Korean: 방탄소년단; RR: Bangtan Sonyeondan), 
also known as the Bangtan Boys, is a seven-member South Korean boy band 
formed in Seoul in 2013. The septet co-writes and produces much of their output. 
Originally a hip hop group, their musical style has evolved to include a wide range of genres.`;

console.log(myString);

var sname = 'Taehyung';
var role = 'Vocalist';
var idol_group = 'BTS';
console.log(`I'm ${sname} and I'm ${role} of ${idol_group} group`);

console.log(`the sum of 1234 and 4321 is ${1234+4321}`);