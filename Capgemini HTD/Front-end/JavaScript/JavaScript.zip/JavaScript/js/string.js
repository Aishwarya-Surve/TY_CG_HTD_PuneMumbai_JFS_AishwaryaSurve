let myString = 'Capgemini trainees are really intellegent'
console.log(myString.indexOf('are'));

console.log(myString.includes('train'));

let reversedString = myString.split('').reverse().join('');

console.log(reversedString);

console.log(myString.charAt(2));

console.log(myString.charCodeAt(1));

