// alert('Are you sure you want to proceed');

// confirm method
// var inputFromUser = confirm('Are you really good');
// console.log(inputFromUser);

// prompt method
// var userName = prompt('Please enter your name');
// console.log(userName);

//console.log('123456');

document.write('Good Morning Everyone');