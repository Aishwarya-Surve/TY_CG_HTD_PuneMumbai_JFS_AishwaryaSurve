//fat arrow function
let add = (a,b) => {
    console.log('The sum is ',a+b);
};

add(2,4);

//fat arrow function with one argument
let printAge = age => {
    console.log('Age is ',age);
};

printAge(23);

//fat arrow function with only return statement
let product = (a,b) => a*b;
console.log(product(22,22));