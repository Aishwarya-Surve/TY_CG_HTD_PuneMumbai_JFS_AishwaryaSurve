//literal way of object creation
var student = {
    sname: 'Taehyung Kim',
    age: 23,
    degree: 'BE',
    phoneNumber: 9384933472
};

//To display the student name
console.log(student.sname);
//To display the whole student object
console.log(student);

//To change the value
student.phoneNumber = 8729378232;
console.log(student.phoneNumber);

//To add another object
student.selectedCompany = 'BigHit';
console.log(student);

//using object constructor
var laptop = new Object();
laptop.brand = 'Dell';
laptop.ram = '8GB';
laptop.pracessor = 'core i5';
laptop.price = 49999;

//To display the object
console.log(laptop);

//To display the keys present in object not their values
console.log(Object.keys(laptop));

//To display the length of the object
console.log(Object.keys(laptop).length);