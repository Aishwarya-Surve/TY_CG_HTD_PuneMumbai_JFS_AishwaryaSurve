let person = {
    name: 'Zayn',
    age: 25
};

let student = {
    ...person,
    uid: 1234,
    percentage: 80.88
};

console.log(student);

let oneDirectionVocalists = ['Zayn','Harry'];
let btsVocalists = ['Taehyung', 'Jungkook', 'Jimin'];

let vocalists = [
    ...oneDirectionVocalists,
    ...btsVocalists,
    'Charli Puth'
];
console.log(vocalists);

//destructuring
let [name1, name2, name3, ...restValues] = vocalists;

console.log(name1);
console.log(name2);
console.log(name3);
console.log(restValues);