// var x = [1234, 'Aishwarya', true, {name = 'Taehyung Kim'}];

// console.log(x[3]);

// for (var i = 0; i <= x.length; i++) {
//     console.log(x[i]);
// }

// var colors = ['purple', 'blue', 'pink', 'red'];
// colors.pop();
// console.log(colors);
// colors.push('violet', 'black');
// console.log(colors);
// colors.shift();
// console.log(colors);
// colors.unshift('orange', 'white');
// console.log(colors);
// colors.splice(4, 2);
// console.log(colors);
// colors.splice(3, 0, 'green', 'silver', 'indian black');
// console.log(colors);
// colors.splice(5, 1, 'yellow');
// console.log(colors);

// colors.forEach(function(value ,index, array){
//     console.log(value, index, array);
// });

// console.log(colors.indexOf('green'));

// var myArray = [1,2,1,3,2,4,3,5,6,7,6,7,8,9,10];

// var x = myArray.filter(function(value){
//     return value > 5;
// });

// console.log(x);

// //filter method for unique values
// var filteredArray = myArray.filter(function(value,index,array){
//     return array.indexOf(value) === index;
// });

// console.log(filteredArray);

// //Strict equals
// // if(123 === '123'){
// //     console.log('true');
// // }else{
// //     console.log('false');
// // }

// for (var x of myArray){
//     console.log(x);
// }

// for(var index in colors){
//     console.log('the value is '+colors[index]+' and the index is '+index);
// }

var movie = {
    name: 'POTC',
    actor: 'Johny Depp'
};

for(var key in movie){
    console.log(key +' : ' +movie[key]);
};

//callback concept
// function test(callback){
//     console.log('test function started');
//     callback();
//     console.log('test funtion ended');
// }

// test(function(){
//     console.log('callback function is being executed');
// });

// setTimeout(function(){
//     console.log('5 seconds done!');
// }, 5000);

// var i = 1;
// setInterval (function(){
//     console.log(i);
//     i++;
// }, 1);
