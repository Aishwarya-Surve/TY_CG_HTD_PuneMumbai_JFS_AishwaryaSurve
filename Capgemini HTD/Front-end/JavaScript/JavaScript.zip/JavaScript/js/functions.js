// Anonymous function with expression
var x = function () {
    console.log('Anonymous function');
}
//calling a function
x();

//naming function
function add(a, b) {
    console.log(a + b);
}
//calling a naming funtion
add(8, 4);

//Immediately invoke funtion expression
(function (x, y) {
    console.log('The value is: ', x*y);
})(4, 6);

//understanding the return keyword
function division(a, b){
    return a/b;
}
console.log(division(84, 12));


