//prompt('Please type your name..');
var myName = 123456;
myName = 'Aishwarya';
console.log(typeof myName);

var areYouGood = true;