"use strict";
exports.__esModule = true;
var circle_1 = require("./circle");
var rectangle_1 = require("./rectangle");
var circle = new circle_1.Circle();
var rectangle = new rectangle_1.Rectangle();
console.log(circle.areaOfCircle(22));
console.log(rectangle.areaOfRectangle(10, 20));
