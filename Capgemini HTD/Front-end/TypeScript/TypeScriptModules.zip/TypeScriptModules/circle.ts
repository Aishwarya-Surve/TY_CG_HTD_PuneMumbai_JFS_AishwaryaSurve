export class Circle {
    circumference(r: number): number {
        return 2 * 3.14 * r;
    }
    areaOfCircle(r: number): number {
        return 3.14 * r * r;
    }
}