"use strict";
exports.__esModule = true;
var Rectangle = /** @class */ (function () {
    function Rectangle() {
    }
    Rectangle.prototype.perimiter = function (l, b) {
        return 2 * (l + b);
    };
    Rectangle.prototype.areaOfRectangle = function (l, b) {
        return l * b;
    };
    return Rectangle;
}());
exports.Rectangle = Rectangle;
