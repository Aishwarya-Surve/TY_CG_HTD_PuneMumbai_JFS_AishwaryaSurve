var Student = /** @class */ (function () {
    function Student(name, age, marks, id) {
        this.name = name;
        this.age = age;
        this.marks = marks;
        this.id = id;
    }
    return Student;
}());
var student1 = new Student('Aishwarya', 22, 89);
console.log(student1);
// student1.printDetails();
var student2 = {
    name: 'Taehyung',
    age: 23,
    marks: 90,
    id: 102
};
console.log(student2);
var students = [
    new Student('Zayn', 25, 86),
    {
        name: 'Taehyung',
        age: 23,
        marks: 90,
        id: 102
    },
    student2,
    student1
];
for (var _i = 0, students_1 = students; _i < students_1.length; _i++) {
    var student = students_1[_i];
    console.log(student);
}
