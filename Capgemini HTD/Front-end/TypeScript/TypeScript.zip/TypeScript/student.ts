class Student {
    constructor(
        public name: string,
        public age: number,
        public marks: number,
        public id?: number) {

    }
    // printDetails(){
    //     console.log(`Name is ${this.name} age is ${this.age} and marks are ${this.marks}`);

    // }
}
let student1 = new Student('Aishwarya', 22, 89);

console.log(student1);
// student1.printDetails();

let student2: Student = {
    name: 'Taehyung',
    age: 23,
    marks: 90,
    id: 102
}

console.log(student2);

let students: Student[] = [
    new Student('Zayn', 25, 86),
    {
        name: 'Taehyung',
        age: 23,
        marks: 90,
        id: 102
    },
    student2,
    student1
];

for(let student of students){
    console.log(student);
}

class Graduate extends Student{
    constructor(
        name: string,
        age: number,
        marks: number,
        id ?: number

    ){
        super(name, age, marks);
    }
}
