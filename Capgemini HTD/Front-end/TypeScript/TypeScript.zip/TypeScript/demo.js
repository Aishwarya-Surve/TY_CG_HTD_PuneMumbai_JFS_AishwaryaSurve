var myName = 'Aishwarya';
// myName = 1234; error : we cannot change the datatype
var company; //impliciltly it will be considered as any
company = 1234;
company = 'Capgemini';
company = true;
//Union type
var age;
age = 6;
age = 'six';
// age = true; error : only number or string can be stored
//tuple
var details = ['Aish', 1234, 5678]; //order of values should be same as datatypes specified
var singers = ['Zayn', 'Taehyung', 'Jimin']; //only string
function add(a, b) {
    return a + b;
}
