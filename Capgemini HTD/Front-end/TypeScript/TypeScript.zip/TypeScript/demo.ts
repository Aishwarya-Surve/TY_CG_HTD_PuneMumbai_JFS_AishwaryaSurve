let myName: string = 'Aishwarya';
// myName = 1234; error : we cannot change the datatype

myName = null; //json - line28
let company; //impliciltly it will be considered as any
company = 1234;
company = 'Capgemini';
company = true;

//Union type
let age: string | number;

age = 6;
age = 'six';
// age = true; error : only number or string can be stored

//tuple
let details: [string, number, number] = ['Aish', 1234, 5678]; //order of values should be same as datatypes specified

let singers: string[] = ['Zayn', 'Taehyung', 'Jimin'] //only string

function add(a: number, b: number): number {
    return a + b;
}